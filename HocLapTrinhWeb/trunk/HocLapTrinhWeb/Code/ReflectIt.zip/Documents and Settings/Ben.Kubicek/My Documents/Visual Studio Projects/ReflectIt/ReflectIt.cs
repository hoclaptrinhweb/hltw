using System;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;

namespace ReflectIt
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class ReflectIt
	{
		#region Constructor
		public ReflectIt()
		{	
		}
		#endregion

		#region Load
		/// <summary>
		/// This function will populate the p_object passed in with the datarow passed in
		/// It is assumed that the datarow columns match exactly with the properties in the
		/// object passed in.
		/// </summary>
		/// <param name="p_dcc"></param>
		/// <param name="p_dr"></param>
		/// <param name="p_object"></param>
		public static void Load(DataColumnCollection p_dcc, DataRow p_dr, Object p_object)
		{
			Type t = p_object.GetType(); //This is used to do the reflection
			for (Int32 i=0;i<=p_dcc.Count -1;i++)
			{
				//Don't ask it just works
				try
				{  //NOTE the datarow column names must match exactly (including case) to the object property names
					t.InvokeMember(p_dcc[i].ColumnName  , BindingFlags.SetProperty , null, p_object, new object[] {p_dr[p_dcc[i].ColumnName]});
				}
				catch (Exception ex)
				{ //Usually you are getting here because a column doesn't exist or it is null
					if (ex.ToString() != null)
					{}
				}
			};//for i
		}
		#endregion

		#region ObjectToTableConvert
		/// <summary>
		/// This method takes in an object and by reflection takes the properties
		/// Creates a table if it doesn't already exist
		/// Adds a row to the table in a dataset.
		/// </summary>
		/// <param name="p_obj"></param>
		/// <param name="p_ds"></param>
		/// <param name="p_tableName"></param>
		public static void ObjectToTableConvert(Object p_obj, ref DataSet p_ds, String p_tableName)
		{
			//we need the type to figure out the properties
			Type t = p_obj.GetType();
			//Get the properties of our type
			PropertyInfo[] tmpP = t.GetProperties();
			
			//We need to create the table if it doesn't already exist
			if (p_ds.Tables[p_tableName] == null)
			{
				p_ds.Tables.Add(p_tableName);
				//Create the columns of the table based off the properties we reflected from the type
				foreach (PropertyInfo xtemp2 in tmpP) 
				{
					p_ds.Tables[p_tableName].Columns.Add(xtemp2.Name,xtemp2.PropertyType);
				} //foreach
			}
			//Now the table should exist so add records to it.
								
			Object[] tmpObj = new Object[tmpP.Length];
				
			for (Int32 i=0;i<=tmpObj.Length-1;i++)
			{
				//tmpObj[i] = tmpP[i].GetValue(p_obj,null);
				tmpObj[i] = t.InvokeMember(tmpP[i].Name  , BindingFlags.GetProperty, null, p_obj, new object[0]);

				
			}
			//Add the row to the table in the dataset
			p_ds.Tables[p_tableName].LoadDataRow(tmpObj,true);
		}
		#endregion
	}
	
}
