using System;
using System.Data;
using System.Data.SqlClient;
using ReflectIt;

namespace TestReflectIt
{
	/// <summary>
	/// Customers is a table in the northwind database that comes with sql server.
	/// This class was created for example purposes only.
	/// </summary>
	public class Customers
	{
		#region Constructor
		public Customers()
		{}
		public Customers(String p_customerID)
		{
			GetCustomer(p_customerID);
		}
		#endregion

		#region Private vars
		private String _customerID;
		private String _companyName;
		private String _contactName;
		private String _contactTitle;
		private String _address;
		private String _city;
		private String _region;
		private String _postalCode;
		private String _country;
		private String _phone;
		private String _fax;
		#endregion

		#region Public Properties
		public String Fax
		{
			get { return _fax; }
			set { _fax = value; }
		}
		public String Phone
		{
			get { return _phone; }
			set { _phone = value; }
		}
		public String Country
		{
			get { return _country; }
			set { _country = value; }
		}
		public String PostalCode
		{
			get { return _postalCode; }
			set { _postalCode = value; }
		}
		public String Region
		{
			get { return _region; }
			set { _region = value; }
		}
		public String City
		{
			get { return _city; }
			set { _city = value; }
		}
		public String Address
		{
			get { return _address; }
			set { _address = value; }
		}
		public String ContactTitle
		{
			get { return _contactTitle; }
			set { _contactTitle = value; }
		}
		public String ContactName
		{
			get { return _contactName; }
			set { _contactName = value; }
		}
		public String CompanyName
		{
			get { return _companyName; }
			set { _companyName = value; }
		}
		public String CustomerID
		{
			get { return _customerID; }
			set { _customerID = value; }
		}
		
		#endregion

		/// <summary>
		/// This method will get the sql data row and call the ReflectIt.Load method which will 
		/// load the datarow into the object
		/// </summary>
		/// <param name="p_customerID"></param>
		public void GetCustomer(String p_customerID)
		{
			SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection();
			sqlConnection.ConnectionString = "Data Source=(local); Initial Catalog=Northwind; User ID=sa; Password=sa; Application Name=Test app for ReflectIt; Max Pool Size=100;";
			sqlConnection.Open();

			SqlCommand sqlCmdGetCustomer = new System.Data.SqlClient.SqlCommand();
			sqlCmdGetCustomer.CommandText = "SELECT * FROM dbo.Customers WHERE CustomerID = @ID";
			sqlCmdGetCustomer.Connection = sqlConnection;
			sqlCmdGetCustomer.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.NVarChar, 5, "CustomerID"));

			sqlCmdGetCustomer.Parameters[0].Value = p_customerID;
			SqlDataAdapter sda = new SqlDataAdapter(sqlCmdGetCustomer);
			DataSet tmpDS = new DataSet();
			sda.Fill(tmpDS);
			sqlConnection.Close();
			if (tmpDS.Tables[0].Rows.Count > 0)
			{
				//Now we call the ReflectIt class to load the object from the datarow passed in
				//NOTE it is assumed that the datarow matches the object in names of datarow columns
				//to object properties.
				ReflectIt.ReflectIt.Load(tmpDS.Tables[0].Columns,tmpDS.Tables[0].Rows[0],this);
			}
		}
	}
}
