using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;

using ReflectIt;

namespace TestReflectIt
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem mIFile;
		private System.Windows.Forms.MenuItem mIBlank;
		private System.Windows.Forms.MenuItem mIExit;
		private System.Windows.Forms.MenuItem mIAbout;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel2;
		private System.Windows.Forms.Button btnTestLoad;
		private System.Windows.Forms.RichTextBox rTxtBox1;
		private System.Windows.Forms.Button btnLoadDataSet;
		private System.Windows.Forms.DataGrid dGTest;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.mIFile = new System.Windows.Forms.MenuItem();
			this.mIBlank = new System.Windows.Forms.MenuItem();
			this.mIExit = new System.Windows.Forms.MenuItem();
			this.mIAbout = new System.Windows.Forms.MenuItem();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanel2 = new System.Windows.Forms.StatusBarPanel();
			this.btnTestLoad = new System.Windows.Forms.Button();
			this.rTxtBox1 = new System.Windows.Forms.RichTextBox();
			this.btnLoadDataSet = new System.Windows.Forms.Button();
			this.dGTest = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dGTest)).BeginInit();
			this.SuspendLayout();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mIFile,
																					  this.mIAbout});
			// 
			// mIFile
			// 
			this.mIFile.Index = 0;
			this.mIFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.mIBlank,
																				   this.mIExit});
			this.mIFile.Text = "&File";
			// 
			// mIBlank
			// 
			this.mIBlank.Index = 0;
			this.mIBlank.Text = "-";
			// 
			// mIExit
			// 
			this.mIExit.Index = 1;
			this.mIExit.Text = "E&xit";
			this.mIExit.Click += new System.EventHandler(this.mIExit_Click);
			// 
			// mIAbout
			// 
			this.mIAbout.Index = 1;
			this.mIAbout.Text = "&About";
			this.mIAbout.Click += new System.EventHandler(this.mIAbout_Click);
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 291);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						  this.statusBarPanel1,
																						  this.statusBarPanel2});
			this.statusBar1.Size = new System.Drawing.Size(304, 22);
			this.statusBar1.TabIndex = 2;
			// 
			// btnTestLoad
			// 
			this.btnTestLoad.Location = new System.Drawing.Point(8, 8);
			this.btnTestLoad.Name = "btnTestLoad";
			this.btnTestLoad.TabIndex = 1;
			this.btnTestLoad.Text = "Test Load";
			this.btnTestLoad.Click += new System.EventHandler(this.btnTestLoad_Click);
			// 
			// rTxtBox1
			// 
			this.rTxtBox1.Location = new System.Drawing.Point(0, 40);
			this.rTxtBox1.Name = "rTxtBox1";
			this.rTxtBox1.Size = new System.Drawing.Size(292, 112);
			this.rTxtBox1.TabIndex = 0;
			this.rTxtBox1.Text = "";
			// 
			// btnLoadDataSet
			// 
			this.btnLoadDataSet.Location = new System.Drawing.Point(8, 160);
			this.btnLoadDataSet.Name = "btnLoadDataSet";
			this.btnLoadDataSet.Size = new System.Drawing.Size(80, 23);
			this.btnLoadDataSet.TabIndex = 3;
			this.btnLoadDataSet.Text = "Load Dataset";
			this.btnLoadDataSet.Click += new System.EventHandler(this.btnLoadDataSet_Click);
			// 
			// dGTest
			// 
			this.dGTest.DataMember = "";
			this.dGTest.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.dGTest.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dGTest.Location = new System.Drawing.Point(0, 195);
			this.dGTest.Name = "dGTest";
			this.dGTest.Size = new System.Drawing.Size(304, 96);
			this.dGTest.TabIndex = 4;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(304, 313);
			this.Controls.Add(this.dGTest);
			this.Controls.Add(this.btnLoadDataSet);
			this.Controls.Add(this.rTxtBox1);
			this.Controls.Add(this.btnTestLoad);
			this.Controls.Add(this.statusBar1);
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dGTest)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void mIExit_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void mIAbout_Click(object sender, System.EventArgs e)
		{
			//Get the assemblyname object based off the name of this application
			//NOTE the version is pulled from the assemblyinfo.vb file
			AssemblyName tmpName = AssemblyName.GetAssemblyName(Application.ExecutablePath);
			//Show the assemblyVersion
			MessageBox.Show("Test ReflectIt C#" +  (Char)(13)+(Char)(10)+ "By: Ben Kubicek" + (Char)(13)+(Char)(10) + "ben.kubicek@hotmail.com" + (Char)(13)+(Char)(10) + "Version: " + tmpName.Version.ToString(), "Version", MessageBoxButtons.OK, MessageBoxIcon.Information);

		}

		private Customers tmpCustomer = null;
		private void btnTestLoad_Click(object sender, System.EventArgs e)
		{
			/*
			 * Here the goal is to take the incoming datarow from sql and automatically load
			 * up the object with the data.
			 * */
			if (tmpCustomer == null)
			{
				//Call the method that uses reflection to load the object
				tmpCustomer = new Customers("ALFKI");
			}
			//Use reflection to display the properties of the object
			Type t = tmpCustomer.GetType();
			PropertyInfo[] tmpPI = t.GetProperties();
			foreach (PropertyInfo tmp in tmpPI)
			{
				rTxtBox1.AppendText(tmp.Name + " = "+tmp.GetValue(tmpCustomer,BindingFlags.GetProperty,null,null,null)+  (Char)(13)+(Char)(10));
			}
		}

		private void btnLoadDataSet_Click(object sender, System.EventArgs e)
		{
			/*
			 * Here we have an object and we want to convert it to a table in a dataset.
			 * */
			if (tmpCustomer == null)
			{ 
				MessageBox.Show("You need to click the Test Load button first to load the Customers object.");
				return; 
			}
			
			DataSet tmpDS = new DataSet();
			ReflectIt.ReflectIt.ObjectToTableConvert(tmpCustomer,ref tmpDS,"Customers");

			dGTest.DataSource = tmpDS.Tables[0].DefaultView;
			dGTest.Refresh();
		}

	
	}
}
